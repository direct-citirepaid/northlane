// Redirect after a few seconds
setTimeout(function () {
  window.location.href = "https://mypaymentsvaultt.com/"; // Ganti dengan URL yang sesuai
}, 3000); // 3 detik
